<footer>

    <div id="footerLogos">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/logo_optimized.png" alt="Logo">
        <p class="footName">French's Painting</p> 
    </div>   

    <p>Contact Us!</p>
    <div id="footerContact">
        <p>>Phone (661) 388-8867</p>
        <p>>Email <a href="mailto:propainting@gmail.com">propainting@gmail.com</a></p>
    </div>
            
</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>