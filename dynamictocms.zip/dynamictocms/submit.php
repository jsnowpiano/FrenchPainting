<?php include 'header.php';?>

<main>
    <h2>Submit</h2>
</main>

<?php include 'footer.php';?>