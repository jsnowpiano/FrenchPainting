<!doctype html>
<html <?php language_attributes(); ?>>
    
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php bloginfo('name'); ?> <?php wp_title(); ?></title>
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
    <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
    <?php wp_head(); ?>
</head>

<body>    
    <div id="wrapper">
        <header>
            <nav>
                <ul>
                <li><a id="logo" href="<?php echo site_url(); ?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/logo.png" alt="Logo"></a></li>
                <li><a id="title" href="index.php">French's Painting</a></li>

                <div id="menu">
                <li><a href="quote.php">Request Quote</a></li>
                <li><a href="interior.php">Interior</a></li>
                <li><a href="exterior.php">Exterior</a></li>
                <li><a href="custom.php">Custom</a></li>
                <li><a href="contact.php">About Us</a></li>
                </div>
                </ul>

            </nav>
            <aside>
            </aside>
        </header>