<?php get_header(); ?>

<div id="mainPage">
        <h1 class="homeSplashText" >Bring a New <br> Shade To <br> Your Home</h1>

        <div id="mainButtons">
        <button onclick="window.location.href='pricing.php';">See our Prices</button>
        <button onclick="window.location.href='quote.php';">Get a Free Quote</button>
        </div>
    </div>

    <main>

<h2>Our Painting <br> Services</h2>
<br>
<?php 
if ( have_posts() ) : 
    while ( have_posts() ) : the_post(); 
        the_content(); 
    endwhile; 
else : 
    _e( 'Sorry, no posts matched your criteria.', 'textdomain' ); 
endif; 
?>
<br>

<div class="list">
    <div class="icon">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/houseIcon.png" alt="Exterior Icon">
        <p>Exterior</p>
    </div>

    <div class="icon">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/interiorIcon.png" alt="Interior Icon">
        <p>Interior</p>
    </div>

    <div class="icon">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/customIcon.png" alt="Custom Icon">
        <p>Custom</p>
    </div>
</div> 
<br>

<div class="list">
    <p>Learn about out expert services that<br> will make your home be the beacon of the neighborhood.</p>
    <p>Check out our process to make your<br> guests in awe when they walk in your home.</p>
    <p>Be sure to see the other services<br> that we can do from cabinets to furnishings</p>
</div>


    <div id="splashImg">
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <h1 class="white">Find Your Price</h1>
        <br><br><br><br><br>
        <button onclick="window.location.href='pricing.php';" class="priceButton">See Pricing</button>
        <br><br><br><br><br>
    </div>

    <h2>Our Work</h2>
    <div class="list">
    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/exampleHouse.png" alt="House">
    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/exampleInterior.png" alt="Interior">
    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/exampleCustom1.png" alt="Custom 1">
    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/exampleCustom2.png" alt="Custom 2">
</div>
    <br>

</main>

<?php get_footer(); ?>